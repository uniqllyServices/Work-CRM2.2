
import React, { useState, useEffect } from 'react';
import { User, Lead, SupportRequest, UserRole, Activity, Notification } from './types';
import { MOCK_USERS, MOCK_LEADS, MOCK_REQUESTS, MOCK_NOTIFICATIONS, Icons } from './constants';
import Sidebar from './components/Sidebar';
import DashboardView from './components/DashboardView';
import UsersView from './components/UsersView';
import LeadsView from './components/LeadsView';
import SupportView from './components/SupportView';
import DialerModal from './components/DialerModal';
import NotificationCenter from './components/NotificationCenter';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [leads, setLeads] = useState<Lead[]>(MOCK_LEADS);
  const [requests, setRequests] = useState<SupportRequest[]>(MOCK_REQUESTS);
  const [notifications, setNotifications] = useState<Notification[]>(MOCK_NOTIFICATIONS);
  const [activeView, setActiveView] = useState('dashboard');
  const [activeCall, setActiveCall] = useState<Lead | null>(null);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginError, setLoginError] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);

  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  // Simulated Login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = users.find(u => u.email.toLowerCase() === loginEmail.toLowerCase());
    if (user) {
      if (!user.active) {
        setLoginError('This account has been deactivated. Contact admin.');
        return;
      }
      setCurrentUser(user);
      setLoginError('');
      setActiveView('dashboard');
    } else {
      setLoginError('User not found. Try admin@nexus.com or sarah@nexus.com');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setLoginEmail('');
  };

  const handleUpdateUser = (updatedUser: User) => {
    setUsers(users.map(u => u.id === updatedUser.id ? updatedUser : u));
    if (currentUser && currentUser.id === updatedUser.id) {
      setCurrentUser(updatedUser);
    }
  };

  const handleAddLeads = (newLeads: Lead[]) => {
    setLeads(prev => [...newLeads, ...prev]);
    
    // Add a notification for the new lead
    if (newLeads.length === 1) {
      const newNotif: Notification = {
        id: 'n-' + Date.now(),
        message: `Lead "${newLeads[0].name}" successfully added to pipeline.`,
        type: 'success',
        timestamp: 'Just now',
        read: false
      };
      setNotifications(prev => [newNotif, ...prev]);
    }
  };

  const handleActionRequest = (id: string, action: 'approved' | 'rejected') => {
    setRequests(requests.map(r => r.id === id ? { ...r, status: action } : r));
    
    // Create notification for admin action
    const req = requests.find(r => r.id === id);
    if (req) {
      const notif: Notification = {
        id: 'n-act-' + Date.now(),
        message: `Support request "${req.subject}" has been ${action}.`,
        type: action === 'approved' ? 'success' : 'info',
        timestamp: 'Just now',
        read: false
      };
      setNotifications(prev => [notif, ...prev]);
    }
  };

  const handleMarkNotifRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const handleClearNotifications = () => {
    setNotifications([]);
    setShowNotifications(false);
  };

  const handleStartCall = (lead: Lead) => {
    setActiveCall(lead);
  };

  const handleEndCall = (lead: Lead, duration: number) => {
    const mins = Math.floor(duration / 60);
    const secs = duration % 60;
    const durationStr = `${mins}:${secs.toString().padStart(2, '0')}`;
    const timestamp = new Date().toLocaleString();
    
    const leadActivity: Activity = {
      id: 'la-' + Date.now(),
      type: 'call',
      timestamp: timestamp,
      detail: `Outgoing call completed. Duration: ${durationStr}.`
    };

    const userActivity: Activity = {
      id: 'ua-' + Date.now(),
      type: 'call',
      timestamp: timestamp,
      detail: `Completed call to ${lead.name} (${durationStr}).`
    };

    // Update Leads
    setLeads(prevLeads => prevLeads.map(l => {
      if (l.id === lead.id) {
        return {
          ...l,
          status: l.status === 'new' ? 'contacted' : l.status,
          activities: [leadActivity, ...(l.activities || [])],
          lastActivity: new Date().toISOString().split('T')[0]
        };
      }
      return l;
    }));

    // Update User Activity
    if (currentUser) {
      const updatedUser = {
        ...currentUser,
        activities: [userActivity, ...(currentUser.activities || [])]
      };
      handleUpdateUser(updatedUser);
    }

    setActiveCall(null);
  };

  const handleWhatsApp = (lead: Lead) => {
    const url = `https://wa.me/${lead.phone.replace(/[^0-9]/g, '')}`;
    const timestamp = new Date().toLocaleString();
    
    if (currentUser) {
      const waActivity: Activity = {
        id: 'ua-wa-' + Date.now(),
        type: 'note',
        timestamp: timestamp,
        detail: `Initiated WhatsApp chat with ${lead.name}.`
      };
      handleUpdateUser({
        ...currentUser,
        activities: [waActivity, ...(currentUser.activities || [])]
      });
    }

    window.open(url, '_blank');
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 p-6">
        <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden p-8">
          <div className="text-center mb-10">
            <h1 className="text-4xl font-black text-blue-600 tracking-tighter mb-2">NEXUS</h1>
            <p className="text-slate-500 font-medium italic">Elevate your CRM workflow</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Email Address</label>
              <input 
                type="email" 
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                placeholder="e.g. admin@nexus.com"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-4 focus:ring-blue-100 focus:border-blue-500 transition-all outline-none"
                required
              />
            </div>
            {loginError && <p className="text-red-500 text-xs font-bold">{loginError}</p>}
            <button 
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-500/20 transform hover:-translate-y-0.5 transition-all"
            >
              Enter Portal
            </button>
          </form>
          <div className="mt-8 pt-6 border-t border-slate-100 text-center">
            <p className="text-slate-400 text-xs">Demo credentials: <br/> <b>admin@nexus.com</b> (Admin) <br/> <b>sarah@nexus.com</b> (User)</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar 
        currentUser={currentUser} 
        activeView={activeView} 
        onNavigate={setActiveView} 
        onLogout={handleLogout}
      />
      
      <main className="ml-64 flex-1 p-8">
        <header className="flex justify-between items-center mb-10 relative">
          <div>
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
              {activeView === 'dashboard' ? 'Insight Hub' : 
               activeView === 'users' ? 'Admin / Users' :
               activeView === 'leads' ? 'Lead Pipeline' : 'Support Tickets'}
            </h2>
            <p className="text-slate-500 font-medium">Welcome back, {currentUser.name}</p>
          </div>
          
          <div className="flex items-center gap-4 relative">
            <div 
              onClick={() => setShowNotifications(!showNotifications)}
              className="bg-white p-2 rounded-xl shadow-sm border border-slate-200 text-slate-400 cursor-pointer hover:text-blue-600 hover:border-blue-200 transition-all relative group"
            >
              <Icons.Bell />
              {unreadNotificationsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 text-white text-[10px] font-black flex items-center justify-center rounded-full border-2 border-white animate-bounce-short">
                  {unreadNotificationsCount}
                </span>
              )}
            </div>

            {showNotifications && (
              <NotificationCenter 
                notifications={notifications}
                onMarkRead={handleMarkNotifRead}
                onClearAll={handleClearNotifications}
                onClose={() => setShowNotifications(false)}
              />
            )}
          </div>
        </header>

        <div className="animate-in fade-in duration-500">
          {activeView === 'dashboard' && <DashboardView user={currentUser} users={users} leads={leads} />}
          {activeView === 'users' && currentUser.role === UserRole.ADMIN && (
            <UsersView users={users} onUpdateUser={handleUpdateUser} />
          )}
          {activeView === 'leads' && (
            <LeadsView 
              user={currentUser} 
              leads={leads} 
              onCall={handleStartCall} 
              onWhatsApp={handleWhatsApp}
              onAddLeads={handleAddLeads}
            />
          )}
          {activeView === 'support' && (
            <SupportView 
              user={currentUser} 
              requests={requests} 
              onAction={handleActionRequest} 
            />
          )}
        </div>
      </main>

      <DialerModal 
        lead={activeCall} 
        onClose={() => setActiveCall(null)} 
        onEndCall={handleEndCall}
      />
    </div>
  );
};

export default App;
