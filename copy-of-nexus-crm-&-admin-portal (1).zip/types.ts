
export enum UserRole {
  ADMIN = 'ADMIN',
  USER = 'USER'
}

export interface Activity {
  id: string;
  type: 'call' | 'email' | 'status_change' | 'note' | 'system';
  timestamp: string;
  detail: string;
}

export interface Notification {
  id: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: string;
  read: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  active: boolean;
  assignedNumber?: string;
  activities?: Activity[];
  permissions: {
    canCall: boolean;
    canWhatsApp: boolean;
    canViewAnalytics: boolean;
  };
}

export interface Lead {
  id: string;
  name: string;
  phone: string;
  status: 'new' | 'contacted' | 'interested' | 'closed';
  lastActivity: string;
  description: string;
  activities?: Activity[];
}

export interface SupportRequest {
  id: string;
  userId: string;
  userName: string;
  subject: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  details: string;
}

export interface AppState {
  currentUser: User | null;
  users: User[];
  leads: Lead[];
  requests: SupportRequest[];
  notifications: Notification[];
}
