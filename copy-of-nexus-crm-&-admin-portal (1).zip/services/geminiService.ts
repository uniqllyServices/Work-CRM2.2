
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const geminiService = {
  async getLeadInsight(leadDescription: string) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analyze this CRM lead: "${leadDescription}". Provide a 2-sentence strategy for conversion.`,
      });
      return response.text;
    } catch (error) {
      console.error("Gemini Error:", error);
      return "AI Insight currently unavailable.";
    }
  },

  async summarizeRequest(requestDetails: string) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Summarize this support request into a simple bullet point: "${requestDetails}"`,
      });
      return response.text;
    } catch (error) {
      console.error("Gemini Error:", error);
      return "Unable to summarize.";
    }
  }
};
