
import React, { useEffect, useState } from 'react';
import { Lead } from '../types';
import { Icons } from '../constants';

interface DialerModalProps {
  lead: Lead | null;
  onClose: () => void;
  onEndCall: (lead: Lead, duration: number) => void;
}

const DialerModal: React.FC<DialerModalProps> = ({ lead, onClose, onEndCall }) => {
  const [status, setStatus] = useState('Dialing...');
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    if (!lead) return;
    setStatus('Dialing...');
    setDuration(0);
    
    const timeout = setTimeout(() => setStatus('Connected'), 2000);
    const interval = setInterval(() => {
      setStatus(prev => {
        if (prev === 'Connected') {
          setDuration(d => d + 1);
        }
        return prev;
      });
    }, 1000);

    return () => {
      clearTimeout(timeout);
      clearInterval(interval);
    };
  }, [lead]);

  if (!lead) return null;

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleHangUp = () => {
    onEndCall(lead, duration);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-300">
      <div className="bg-slate-900 w-full max-w-sm rounded-[3rem] p-8 text-center text-white border border-slate-800 shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Animated Pulsing Ring */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
          <div className="w-64 h-64 border-4 border-blue-500 rounded-full animate-ping" />
        </div>

        <div className="relative z-10">
          <div className="w-24 h-24 mx-auto bg-slate-800 rounded-full flex items-center justify-center text-4xl mb-6 border border-slate-700 shadow-inner">
            {lead.name.charAt(0)}
          </div>
          
          <h2 className="text-2xl font-bold mb-1 tracking-tight">{lead.name}</h2>
          <p className="text-slate-400 mb-8 font-medium">{lead.phone}</p>
          
          <div className="mb-12 h-16 flex flex-col justify-center">
            <span className={`block text-lg font-bold tracking-wider uppercase ${status === 'Connected' ? 'text-green-400' : 'text-blue-400'}`}>
              {status}
            </span>
            {status === 'Connected' && (
              <span className="text-2xl font-mono mt-1 font-bold text-white tabular-nums">{formatTime(duration)}</span>
            )}
          </div>

          <div className="flex justify-center gap-8">
            <button className="w-14 h-14 rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 transition-colors border border-slate-700">
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"/><path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/></svg>
            </button>
            <button 
              onClick={handleHangUp}
              title="End Call"
              className="w-16 h-16 rounded-full bg-red-600 flex items-center justify-center hover:bg-red-700 transition-all shadow-lg shadow-red-600/40 transform hover:scale-110 active:scale-90"
            >
              <Icons.Close />
            </button>
            <button className="w-14 h-14 rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 transition-colors border border-slate-700">
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DialerModal;
