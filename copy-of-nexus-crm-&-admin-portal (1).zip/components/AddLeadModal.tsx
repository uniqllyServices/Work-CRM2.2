
import React, { useState } from 'react';
import { Lead } from '../types';
import { Icons } from '../constants';

interface AddLeadModalProps {
  onClose: () => void;
  onAdd: (leads: Lead[]) => void;
}

const AddLeadModal: React.FC<AddLeadModalProps> = ({ onClose, onAdd }) => {
  const [tab, setTab] = useState<'manual' | 'bulk' | 'quick'>('manual');
  const [manualLead, setManualLead] = useState({ name: '', phone: '', description: '', source: 'Direct' });
  const [quickPaste, setQuickPaste] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newLead: Lead = {
      id: 'l-' + Date.now(),
      name: manualLead.name,
      phone: manualLead.phone,
      description: `[Source: ${manualLead.source}] ${manualLead.description}`,
      status: 'new',
      lastActivity: new Date().toISOString().split('T')[0],
      activities: [
        { 
          id: 'a-' + Date.now(), 
          type: 'note', 
          timestamp: new Date().toLocaleString(), 
          detail: `Lead manually added via ${manualLead.source} source.` 
        }
      ]
    };
    onAdd([newLead]);
    onClose();
  };

  const handleQuickPasteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const lines = quickPaste.split('\n').filter(l => l.trim().length > 5);
    const newLeads: Lead[] = lines.map((line, idx) => ({
      id: `l-quick-${Date.now()}-${idx}`,
      name: line.split(',')[0] || `Lead ${idx + 1}`,
      phone: line.split(',')[1] || 'No number provided',
      description: line.split(',')[2] || 'Quick paste import',
      status: 'new',
      lastActivity: new Date().toISOString().split('T')[0],
      activities: [{ id: `a-q-${idx}`, type: 'note', timestamp: new Date().toLocaleString(), detail: 'Imported via Quick Paste' }]
    }));
    onAdd(newLeads);
    onClose();
  };

  const simulateBulkUpload = () => {
    if (isUploading) return;
    setIsUploading(true);
    setUploadProgress(0);

    const duration = 2000; // 2 seconds
    const interval = 50; // update every 50ms
    const step = 100 / (duration / interval);

    const timer = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        return Math.min(prev + step, 100);
      });
    }, interval);

    setTimeout(() => {
      const mockBulkLeads: Lead[] = [
        {
          id: 'lb-' + Date.now() + 1,
          name: 'Tech Solutions Inc',
          phone: '+1 888-999-0001',
          description: 'Imported from Spreadsheet: Quarterly Leads List',
          status: 'new',
          lastActivity: new Date().toISOString().split('T')[0],
          activities: [{ id: 'ab1', type: 'note', timestamp: new Date().toLocaleString(), detail: 'Imported via bulk upload.' }]
        },
        {
          id: 'lb-' + Date.now() + 2,
          name: 'Global Ventures',
          phone: '+1 888-999-0002',
          description: 'Imported from Spreadsheet: Quarterly Leads List',
          status: 'new',
          lastActivity: new Date().toISOString().split('T')[0],
          activities: [{ id: 'ab2', type: 'note', timestamp: new Date().toLocaleString(), detail: 'Imported via bulk upload.' }]
        }
      ];
      onAdd(mockBulkLeads);
      setIsUploading(false);
      onClose();
    }, duration + 500);
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Add New Leads</h2>
            <p className="text-xs text-slate-500 font-medium">Expand your CRM pipeline</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors text-slate-400">
            <Icons.Close />
          </button>
        </div>

        <div className="flex p-2 bg-slate-100 mx-6 mt-6 rounded-xl space-x-1">
          <button 
            onClick={() => setTab('manual')}
            className={`flex-1 py-2 text-[11px] font-bold uppercase tracking-wider rounded-lg transition-all ${tab === 'manual' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:bg-slate-200'}`}
          >
            Manual
          </button>
          <button 
            onClick={() => setTab('bulk')}
            className={`flex-1 py-2 text-[11px] font-bold uppercase tracking-wider rounded-lg transition-all ${tab === 'bulk' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:bg-slate-200'}`}
          >
            Sheet Upload
          </button>
          <button 
            onClick={() => setTab('quick')}
            className={`flex-1 py-2 text-[11px] font-bold uppercase tracking-wider rounded-lg transition-all ${tab === 'quick' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:bg-slate-200'}`}
          >
            Quick Paste
          </button>
        </div>

        <div className="p-6">
          {tab === 'manual' && (
            <form onSubmit={handleManualSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1 ml-1">Company/Lead Name</label>
                  <input 
                    type="text" 
                    required
                    value={manualLead.name}
                    onChange={(e) => setManualLead({...manualLead, name: e.target.value})}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm transition-all"
                    placeholder="Acme Corp"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1 ml-1">Phone Number</label>
                  <input 
                    type="tel" 
                    required
                    value={manualLead.phone}
                    onChange={(e) => setManualLead({...manualLead, phone: e.target.value})}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                    placeholder="+1 555-0000"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1 ml-1">Lead Source</label>
                  <select 
                    value={manualLead.source}
                    onChange={(e) => setManualLead({...manualLead, source: e.target.value})}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                  >
                    <option>Direct</option>
                    <option>Referral</option>
                    <option>Ads</option>
                    <option>Social Media</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1 ml-1">Description/Note</label>
                <textarea 
                  value={manualLead.description}
                  onChange={(e) => setManualLead({...manualLead, description: e.target.value})}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none min-h-[80px] text-sm"
                  placeholder="Additional context about this lead..."
                ></textarea>
              </div>
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-lg shadow-blue-600/20 active:scale-[0.98]">
                Add to Pipeline
              </button>
            </form>
          )}

          {tab === 'bulk' && (
            <div className="text-center py-4 space-y-6">
              <div className="border-2 border-dashed border-slate-200 rounded-3xl p-10 bg-slate-50 flex flex-col items-center group hover:border-blue-400 transition-colors cursor-pointer" onClick={simulateBulkUpload}>
                <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 mb-4 group-hover:scale-110 transition-transform">
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 17v-2a2 2 0 00-2-2H5a2 2 0 00-2-2H5a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                </div>
                <h3 className="font-bold text-slate-900">Upload CSV/Excel</h3>
                <p className="text-xs text-slate-500 max-w-[200px] mx-auto mt-1 leading-relaxed">Import contacts instantly from your sales spreadsheets</p>
                
                {isUploading && (
                  <div className="mt-6 w-full max-w-[240px]">
                    <div className="flex justify-between items-center mb-1.5">
                      <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider">Uploading...</span>
                      <span className="text-[10px] font-bold text-blue-600">{Math.round(uploadProgress)}%</span>
                    </div>
                    <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-600 transition-all duration-75 ease-linear"
                        style={{ width: `${uploadProgress}%` }}
                      ></div>
                    </div>
                    <span className="text-[10px] text-slate-400 mt-2 block italic">Processing records...</span>
                  </div>
                )}
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Supported formats: .csv, .xlsx, .numbers</p>
            </div>
          )}

          {tab === 'quick' && (
            <form onSubmit={handleQuickPasteSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1 ml-1">Paste Raw Text</label>
                <textarea 
                  required
                  value={quickPaste}
                  onChange={(e) => setQuickPaste(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none min-h-[150px] text-sm font-mono"
                  placeholder="Format: Name, Phone, Note (one per line)"
                ></textarea>
                <p className="text-[10px] text-slate-500 mt-2 leading-tight">Example:<br/>John Wick, +1 222-3333, Needs custom tools<br/>Bruce Wayne, +1 444-5555, High priority</p>
              </div>
              <button className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3.5 rounded-xl transition-all shadow-xl">
                Parse & Import
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default AddLeadModal;
