
import React from 'react';
import { Notification } from '../types';
import { Icons } from '../constants';

interface NotificationCenterProps {
  notifications: Notification[];
  onMarkRead: (id: string) => void;
  onClearAll: () => void;
  onClose: () => void;
}

const NotificationCenter: React.FC<NotificationCenterProps> = ({ 
  notifications, 
  onMarkRead, 
  onClearAll,
  onClose 
}) => {
  const unreadCount = notifications.filter(n => !n.read).length;

  const getTypeStyles = (type: Notification['type']) => {
    switch (type) {
      case 'info': return 'bg-blue-100 text-blue-600';
      case 'success': return 'bg-emerald-100 text-emerald-600';
      case 'warning': return 'bg-amber-100 text-amber-600';
      case 'error': return 'bg-rose-100 text-rose-600';
      default: return 'bg-slate-100 text-slate-600';
    }
  };

  return (
    <div className="absolute right-0 mt-3 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden z-[100] animate-in slide-in-from-top-2 duration-200">
      <div className="p-4 border-b border-slate-50 flex items-center justify-between bg-slate-50/50">
        <div>
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">Activity Alerts</h3>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{unreadCount} unread messages</p>
        </div>
        <div className="flex items-center gap-1">
          <button 
            onClick={onClearAll}
            className="text-[10px] font-black text-blue-600 hover:text-blue-800 uppercase px-2 py-1 rounded transition-colors"
          >
            Clear All
          </button>
          <button onClick={onClose} className="p-1 hover:bg-slate-200 rounded-full transition-colors text-slate-400">
            <Icons.Close />
          </button>
        </div>
      </div>

      <div className="max-h-[400px] overflow-y-auto divide-y divide-slate-50">
        {notifications.length > 0 ? (
          notifications.map(notification => (
            <div 
              key={notification.id} 
              onClick={() => !notification.read && onMarkRead(notification.id)}
              className={`p-4 hover:bg-slate-50 transition-colors cursor-pointer relative ${!notification.read ? 'bg-blue-50/30' : ''}`}
            >
              {!notification.read && (
                <div className="absolute top-4 right-4 w-2 h-2 bg-blue-600 rounded-full"></div>
              )}
              <div className="flex gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${getTypeStyles(notification.type)}`}>
                  <Icons.Dashboard /> {/* Generic icon for now */}
                </div>
                <div className="space-y-1">
                  <p className={`text-xs leading-relaxed ${notification.read ? 'text-slate-600' : 'text-slate-900 font-bold'}`}>
                    {notification.message}
                  </p>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
                    {notification.timestamp}
                  </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="p-10 text-center">
            <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-3 text-slate-300">
              <Icons.Bell />
            </div>
            <p className="text-xs text-slate-400 italic">No recent notifications</p>
          </div>
        )}
      </div>

      <div className="p-3 bg-slate-50 border-t border-slate-100 text-center">
        <button className="text-[10px] font-black text-slate-400 hover:text-slate-600 uppercase tracking-widest">
          View All Notification History
        </button>
      </div>
    </div>
  );
};

export default NotificationCenter;
