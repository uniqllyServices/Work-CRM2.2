
import React from 'react';
import { UserRole, User } from '../types';
import { Icons } from '../constants';

interface SidebarProps {
  currentUser: User | null;
  activeView: string;
  onNavigate: (view: string) => void;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentUser, activeView, onNavigate, onLogout }) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Icons.Dashboard, roles: [UserRole.ADMIN, UserRole.USER] },
    { id: 'leads', label: 'CRM Leads', icon: Icons.Leads, roles: [UserRole.ADMIN, UserRole.USER] },
    { id: 'users', label: 'User Management', icon: Icons.Users, roles: [UserRole.ADMIN] },
    { id: 'support', label: 'Support & Requests', icon: Icons.Support, roles: [UserRole.ADMIN, UserRole.USER] },
  ];

  const filteredNavItems = navItems.filter(item => 
    currentUser && item.roles.includes(currentUser.role)
  );

  return (
    <div className="w-64 h-screen bg-slate-900 text-white flex flex-col fixed left-0 top-0 shadow-xl z-20">
      <div className="p-6 border-b border-slate-800">
        <h1 className="text-2xl font-bold tracking-tight text-blue-400">NEXUS CRM</h1>
        <p className="text-xs text-slate-400 mt-1 uppercase tracking-widest">{currentUser?.role} PANEL</p>
      </div>

      <nav className="flex-1 mt-6 px-4 space-y-2">
        {filteredNavItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
              activeView === item.id 
                ? 'bg-blue-600 text-white shadow-lg' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <item.icon />
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-6 border-t border-slate-800">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center border border-slate-600">
            {currentUser?.name.charAt(0)}
          </div>
          <div className="overflow-hidden">
            <p className="text-sm font-semibold truncate">{currentUser?.name}</p>
            <p className="text-xs text-slate-500 truncate">{currentUser?.email}</p>
          </div>
        </div>
        <button 
          onClick={onLogout}
          className="w-full py-2 px-4 rounded-lg bg-red-900/30 text-red-400 border border-red-900/50 hover:bg-red-800/40 transition-colors text-sm font-semibold"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
