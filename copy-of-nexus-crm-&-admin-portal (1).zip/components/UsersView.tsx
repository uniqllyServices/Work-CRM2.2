
import React, { useState } from 'react';
import { User, Activity } from '../types';
import { Icons } from '../constants';

interface UsersViewProps {
  users: User[];
  onUpdateUser: (updatedUser: User) => void;
}

const UsersView: React.FC<UsersViewProps> = ({ users, onUpdateUser }) => {
  const [expandedUserFeed, setExpandedUserFeed] = useState<Record<string, boolean>>({});

  const toggleStatus = (user: User) => {
    const newStatus = !user.active;
    const newActivity: Activity = {
      id: 'sys-' + Date.now(),
      type: 'status_change',
      timestamp: new Date().toLocaleString(),
      detail: `Account status toggled to ${newStatus ? 'Active' : 'Disabled'}.`
    };
    onUpdateUser({ 
      ...user, 
      active: newStatus,
      activities: [newActivity, ...(user.activities || [])]
    });
  };

  const toggleFeed = (userId: string) => {
    setExpandedUserFeed(prev => ({ ...prev, [userId]: !prev[userId] }));
  };

  const updatePermission = (user: User, key: keyof User['permissions'], value: boolean) => {
    const newActivity: Activity = {
      id: 'sys-' + Date.now(),
      type: 'system',
      timestamp: new Date().toLocaleString(),
      detail: `Permission '${key}' updated to ${value}.`
    };
    onUpdateUser({
      ...user,
      permissions: {
        ...user.permissions,
        [key]: value
      },
      activities: [newActivity, ...(user.activities || [])]
    });
  };

  const updateNumber = (user: User, num: string) => {
    onUpdateUser({ ...user, assignedNumber: num });
  };

  const getActivityIcon = (type: Activity['type']) => {
    switch (type) {
      case 'call': return <Icons.Call />;
      case 'status_change': return <Icons.Dashboard />;
      case 'system': return <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>;
      default: return <Icons.More />;
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/30">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Agent Management</h2>
          <p className="text-xs text-slate-500 font-medium mt-0.5">Configure access, assign virtual numbers, and track agent activity feeds.</p>
        </div>
        <button className="bg-blue-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 active:scale-95 flex items-center gap-2">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 4v16m8-8H4"/></svg>
          Add Agent
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-black tracking-widest border-b border-slate-100">
            <tr>
              <th className="px-6 py-4">Agent Identification</th>
              <th className="px-6 py-4">Account Status</th>
              <th className="px-6 py-4">Number & Access Controls</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.map(user => (
              <React.Fragment key={user.id}>
                <tr className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center font-bold text-white shadow-lg shadow-slate-900/10">
                        {user.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-slate-900 text-sm">{user.name}</p>
                        <p className="text-xs text-slate-400 font-medium">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <button 
                      onClick={() => toggleStatus(user)}
                      className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-tight transition-all border ${
                        user.active 
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100' 
                          : 'bg-rose-50 text-rose-700 border-rose-200 opacity-60 hover:opacity-100'
                      }`}
                    >
                      {user.active ? 'Active' : 'Disabled'}
                    </button>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex flex-col gap-3">
                      <div className="relative max-w-[200px]">
                        <input 
                          type="text" 
                          value={user.assignedNumber || ''} 
                          onChange={(e) => updateNumber(user, e.target.value)}
                          placeholder="Assign Number..."
                          className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 w-full font-mono font-bold outline-none transition-all hover:border-slate-300 placeholder:font-sans placeholder:font-normal"
                        />
                      </div>
                      
                      <div className="flex items-center gap-6">
                        {/* WhatsApp Toggle */}
                        <div className="flex items-center gap-3">
                          <div className={`p-1.5 rounded-lg ${user.permissions.canWhatsApp ? 'text-green-600 bg-green-50' : 'text-slate-400 bg-slate-100'}`}>
                            <Icons.WhatsApp />
                          </div>
                          <div className="flex flex-col">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">WhatsApp</span>
                            <button 
                              onClick={() => updatePermission(user, 'canWhatsApp', !user.permissions.canWhatsApp)}
                              className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none ${
                                user.permissions.canWhatsApp ? 'bg-green-500' : 'bg-slate-300'
                              }`}
                            >
                              <span className={`inline-block h-3 w-3 transform rounded-full bg-white transition-transform duration-200 ease-in-out ${
                                user.permissions.canWhatsApp ? 'translate-x-5' : 'translate-x-1'
                              }`} />
                            </button>
                          </div>
                        </div>

                        {/* Call Toggle */}
                        <div className="flex items-center gap-3">
                          <div className={`p-1.5 rounded-lg ${user.permissions.canCall ? 'text-blue-600 bg-blue-50' : 'text-slate-400 bg-slate-100'}`}>
                            <Icons.Call />
                          </div>
                          <div className="flex flex-col">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Voice Call</span>
                            <button 
                              onClick={() => updatePermission(user, 'canCall', !user.permissions.canCall)}
                              className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none ${
                                user.permissions.canCall ? 'bg-blue-500' : 'bg-slate-300'
                              }`}
                            >
                              <span className={`inline-block h-3 w-3 transform rounded-full bg-white transition-transform duration-200 ease-in-out ${
                                user.permissions.canCall ? 'translate-x-5' : 'translate-x-1'
                              }`} />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={() => toggleFeed(user.id)}
                        title="View Activity Feed"
                        className={`p-2 rounded-xl transition-all ${
                          expandedUserFeed[user.id] 
                            ? 'bg-blue-600 text-white shadow-lg' 
                            : 'text-slate-400 hover:text-slate-900 hover:bg-slate-100'
                        }`}
                      >
                        <Icons.History />
                      </button>
                      <button className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-all">
                        <Icons.More />
                      </button>
                    </div>
                  </td>
                </tr>
                {expandedUserFeed[user.id] && (
                  <tr className="bg-slate-50/50">
                    <td colSpan={4} className="px-10 py-6">
                      <div className="max-w-3xl animate-in slide-in-from-top-2 duration-300">
                        <div className="flex items-center justify-between mb-4">
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Agent Activity Timeline</h4>
                          <span className="text-[10px] font-bold text-slate-400">Showing last {user.activities?.length || 0} events</span>
                        </div>
                        <div className="space-y-4 border-l-2 border-slate-200 pl-6 ml-2">
                          {user.activities && user.activities.length > 0 ? (
                            user.activities.map((activity, idx) => (
                              <div key={activity.id} className="relative">
                                {/* Dot on the timeline */}
                                <div className={`absolute -left-[31px] top-1 w-2.5 h-2.5 rounded-full border-2 border-white ${
                                  activity.type === 'call' ? 'bg-blue-500' :
                                  activity.type === 'status_change' ? 'bg-purple-500' :
                                  activity.type === 'system' ? 'bg-slate-400' : 'bg-slate-300'
                                } shadow-sm`}></div>
                                
                                <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
                                  <div className="bg-white p-2 rounded-lg shadow-sm border border-slate-100 flex items-center justify-center w-8 h-8 text-slate-400">
                                    {getActivityIcon(activity.type)}
                                  </div>
                                  <div>
                                    <p className="text-sm font-bold text-slate-800 leading-tight">{activity.detail}</p>
                                    <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-tighter mt-0.5">{activity.timestamp}</p>
                                  </div>
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className="py-4 text-center">
                              <p className="text-xs text-slate-400 italic">No activity logs recorded for this agent.</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
      <div className="p-6 bg-slate-50/50 border-t border-slate-100">
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest flex items-center gap-2">
          <svg className="w-3.5 h-3.5 text-blue-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd"></path></svg>
          History logs are immutable and provide an audit trail for performance reviews.
        </p>
      </div>
    </div>
  );
};

export default UsersView;
