
import React, { useState } from 'react';
import { Lead, User, Activity } from '../types';
import { Icons } from '../constants';
import { geminiService } from '../services/geminiService';
import AddLeadModal from './AddLeadModal';

interface LeadsViewProps {
  user: User;
  leads: Lead[];
  onCall: (lead: Lead) => void;
  onWhatsApp: (lead: Lead) => void;
  onAddLeads: (leads: Lead[]) => void;
}

const LeadsView: React.FC<LeadsViewProps> = ({ user, leads, onCall, onWhatsApp, onAddLeads }) => {
  const [insight, setInsight] = useState<Record<string, string>>({});
  const [loadingInsight, setLoadingInsight] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState<'all' | Lead['status']>('all');
  const [expandedLogs, setExpandedLogs] = useState<Record<string, boolean>>({});
  const [showAddModal, setShowAddModal] = useState(false);

  const fetchInsight = async (leadId: string, desc: string) => {
    setLoadingInsight(leadId);
    const text = await geminiService.getLeadInsight(desc);
    if (text) {
      setInsight(prev => ({ ...prev, [leadId]: text }));
    }
    setLoadingInsight(null);
  };

  const toggleLog = (leadId: string) => {
    setExpandedLogs(prev => ({ ...prev, [leadId]: !prev[leadId] }));
  };

  const filteredLeads = activeFilter === 'all' 
    ? leads 
    : leads.filter(lead => lead.status === activeFilter);

  const filterOptions: { label: string; value: 'all' | Lead['status'] }[] = [
    { label: 'All Leads', value: 'all' },
    { label: 'New', value: 'new' },
    { label: 'Contacted', value: 'contacted' },
    { label: 'Interested', value: 'interested' },
    { label: 'Closed', value: 'closed' },
  ];

  const getActivityIcon = (type: Activity['type']) => {
    switch (type) {
      case 'call': return <Icons.Call />;
      case 'email': return <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>;
      case 'status_change': return <Icons.Dashboard />;
      default: return <Icons.More />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Action Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-2 p-1 bg-slate-200/50 rounded-xl w-fit">
          {filterOptions.map((opt) => (
            <button
              key={opt.value}
              onClick={() => setActiveFilter(opt.value)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeFilter === opt.value
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              {opt.label}
              <span className="ml-2 px-1.5 py-0.5 rounded-md bg-slate-100 text-[10px] text-slate-500">
                {opt.value === 'all' ? leads.length : leads.filter(l => l.status === opt.value).length}
              </span>
            </button>
          ))}
        </div>

        <button 
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-bold shadow-lg shadow-blue-500/20 transition-all transform hover:scale-[1.02]"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 4v16m8-8H4"/></svg>
          Add Lead
        </button>
      </div>

      {filteredLeads.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 border-dashed p-20 text-center">
          <p className="text-slate-400 font-medium italic">No leads found in this category.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 items-start">
          {filteredLeads.map(lead => (
            <div key={lead.id} className="bg-white rounded-2xl shadow-sm border border-slate-200 flex flex-col hover:shadow-md transition-shadow animate-in fade-in slide-in-from-bottom-2 duration-300 overflow-hidden">
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">{lead.name}</h3>
                    <p className="text-sm text-slate-500 font-medium">{lead.phone}</p>
                  </div>
                  <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${
                    lead.status === 'new' ? 'bg-blue-100 text-blue-700' :
                    lead.status === 'contacted' ? 'bg-yellow-100 text-yellow-700' :
                    lead.status === 'interested' ? 'bg-purple-100 text-purple-700' : 'bg-green-100 text-green-700'
                  }`}>
                    {lead.status}
                  </span>
                </div>
                
                <p className="text-sm text-slate-600 line-clamp-2 mb-4 italic">
                  "{lead.description}"
                </p>

                <div className="space-y-3 mb-6">
                  <button 
                    onClick={() => fetchInsight(lead.id, lead.description)}
                    disabled={loadingInsight === lead.id}
                    className="text-xs font-semibold text-blue-600 bg-blue-50 px-3 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-100 transition-colors w-full justify-center"
                  >
                    {loadingInsight === lead.id ? 'Generating...' : '✨ Get AI Strategy'}
                  </button>
                  
                  {insight[lead.id] && (
                    <div className="p-3 bg-slate-50 rounded-lg border border-blue-100 animate-in fade-in slide-in-from-top-1">
                      <p className="text-[11px] text-slate-700 font-medium leading-relaxed">
                        {insight[lead.id]}
                      </p>
                    </div>
                  )}
                </div>

                <div className="flex gap-2 pt-4 border-t border-slate-100 mb-4">
                  {user.permissions.canCall && (
                    <button 
                      onClick={() => onCall(lead)}
                      className="flex-1 flex items-center justify-center gap-2 bg-slate-900 text-white py-2 rounded-lg text-sm font-semibold hover:bg-slate-800 transition-all"
                    >
                      <Icons.Call /> Call
                    </button>
                  )}
                  {user.permissions.canWhatsApp && (
                    <button 
                      onClick={() => onWhatsApp(lead)}
                      className="flex-1 flex items-center justify-center gap-2 bg-green-600 text-white py-2 rounded-lg text-sm font-semibold hover:bg-green-700 transition-all"
                    >
                      <Icons.WhatsApp /> WhatsApp
                    </button>
                  )}
                </div>

                {/* Activity Log Toggle */}
                <button 
                  onClick={() => toggleLog(lead.id)}
                  className="w-full flex items-center justify-between text-xs font-bold text-slate-500 hover:text-slate-800 py-2 border-t border-slate-50 transition-colors"
                >
                  <span className="flex items-center gap-2 uppercase tracking-wider">
                    <Icons.More /> Activity Log
                  </span>
                  {expandedLogs[lead.id] ? <Icons.ChevronUp /> : <Icons.ChevronDown />}
                </button>
              </div>

              {/* Collapsible Content */}
              {expandedLogs[lead.id] && (
                <div className="bg-slate-50/80 border-t border-slate-100 p-4 space-y-3 animate-in slide-in-from-top-2 duration-200">
                  {lead.activities && lead.activities.length > 0 ? (
                    lead.activities.map(activity => (
                      <div key={activity.id} className="flex gap-3">
                        <div className="mt-0.5 text-slate-400 p-1.5 bg-white rounded-lg shadow-sm h-fit">
                          {getActivityIcon(activity.type)}
                        </div>
                        <div>
                          <p className="text-[11px] font-bold text-slate-800">{activity.detail}</p>
                          <p className="text-[10px] text-slate-400 font-medium">{activity.timestamp}</p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-[10px] text-slate-400 italic text-center py-2">No activities logged yet.</p>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {showAddModal && (
        <AddLeadModal 
          onClose={() => setShowAddModal(false)}
          onAdd={onAddLeads}
        />
      )}
    </div>
  );
};

export default LeadsView;
