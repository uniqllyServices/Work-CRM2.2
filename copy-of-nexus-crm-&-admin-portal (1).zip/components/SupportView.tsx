
import React from 'react';
import { SupportRequest, UserRole, User } from '../types';
import { Icons } from '../constants';

interface SupportViewProps {
  user: User;
  requests: SupportRequest[];
  onAction: (id: string, action: 'approved' | 'rejected') => void;
}

const SupportView: React.FC<SupportViewProps> = ({ user, requests, onAction }) => {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="p-6 border-b border-slate-100 flex justify-between items-center">
        <h2 className="text-xl font-bold">Help & Support Center</h2>
        {user.role === UserRole.USER && (
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-blue-700 transition-colors">
            New Support Request
          </button>
        )}
      </div>

      <div className="p-0">
        {requests.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <div className="flex justify-center mb-4"><Icons.Support /></div>
            <p>No active support requests found.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {requests.map(req => (
              <div key={req.id} className="p-6 hover:bg-slate-50 transition-colors flex flex-col md:flex-row gap-4 items-start justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{req.subject}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      req.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                      req.status === 'approved' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {req.status}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600">{req.details}</p>
                  <div className="flex items-center gap-4 text-xs text-slate-400 mt-2">
                    <span className="flex items-center gap-1 font-medium"><Icons.Users /> {req.userName}</span>
                    <span>{req.createdAt}</span>
                  </div>
                </div>

                {user.role === UserRole.ADMIN && req.status === 'pending' && (
                  <div className="flex gap-2">
                    <button 
                      onClick={() => onAction(req.id, 'rejected')}
                      className="px-4 py-2 rounded-lg border border-red-200 text-red-600 text-xs font-bold hover:bg-red-50 transition-colors"
                    >
                      Reject
                    </button>
                    <button 
                      onClick={() => onAction(req.id, 'approved')}
                      className="px-4 py-2 rounded-lg bg-green-600 text-white text-xs font-bold hover:bg-green-700 transition-colors"
                    >
                      Approve
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default SupportView;
