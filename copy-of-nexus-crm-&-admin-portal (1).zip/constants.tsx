
import React from 'react';
import { User, UserRole, Lead, SupportRequest, Notification } from './types';

export const MOCK_USERS: User[] = [
  {
    id: '1',
    name: 'Admin Nexus',
    email: 'admin@nexus.com',
    role: UserRole.ADMIN,
    active: true,
    activities: [
      { id: 'ua1', type: 'system', timestamp: '2023-10-26 09:00 AM', detail: 'System login successful.' },
      { id: 'ua2', type: 'status_change', timestamp: '2023-10-26 10:15 AM', detail: 'Deactivated user: John Doe' }
    ],
    permissions: { canCall: true, canWhatsApp: true, canViewAnalytics: true }
  },
  {
    id: '2',
    name: 'Sarah Connor',
    email: 'sarah@nexus.com',
    role: UserRole.USER,
    active: true,
    assignedNumber: '+1 555-0102',
    activities: [
      { id: 'ua3', type: 'call', timestamp: '2023-10-25 02:30 PM', detail: 'Called Lead: Wayne Enterprises (Duration: 5:12)' },
      { id: 'ua4', type: 'note', timestamp: '2023-10-25 03:00 PM', detail: 'Added note to Wayne Enterprises: Requested demo.' }
    ],
    permissions: { canCall: true, canWhatsApp: false, canViewAnalytics: false }
  },
  {
    id: '3',
    name: 'John Doe',
    email: 'john@nexus.com',
    role: UserRole.USER,
    active: false,
    assignedNumber: '+1 555-0999',
    activities: [
      { id: 'ua5', type: 'system', timestamp: '2023-10-20 11:00 AM', detail: 'Account created by Admin.' }
    ],
    permissions: { canCall: false, canWhatsApp: true, canViewAnalytics: false }
  },
  {
    id: '4',
    name: 'Alice Smith',
    email: 'alice@nexus.com',
    role: UserRole.USER,
    active: true,
    assignedNumber: '+1 555-0104',
    activities: [
      { id: 'ua6', type: 'system', timestamp: '2023-10-26 08:30 AM', detail: 'Assigned number: +1 555-0104' }
    ],
    permissions: { canCall: true, canWhatsApp: true, canViewAnalytics: false }
  }
];

export const MOCK_LEADS: Lead[] = [
  { 
    id: 'l1', 
    name: 'Acme Corp', 
    phone: '+1234567890', 
    status: 'new', 
    lastActivity: '2023-10-25', 
    description: 'Interested in enterprise license',
    activities: [
      { id: 'a1', type: 'note', timestamp: '2023-10-25 10:00 AM', detail: 'Initial inquiry received via website.' },
      { id: 'a2', type: 'status_change', timestamp: '2023-10-25 10:05 AM', detail: 'Status set to New.' }
    ]
  },
  { 
    id: 'l2', 
    name: 'Wayne Enterprises', 
    phone: '+0987654321', 
    status: 'contacted', 
    lastActivity: '2023-10-24', 
    description: 'Requires custom integration',
    activities: [
      { id: 'a3', type: 'call', timestamp: '2023-10-24 02:30 PM', detail: 'Outbound call - spoke with Bruce. He requested a demo.' },
      { id: 'a4', type: 'email', timestamp: '2023-10-24 03:00 PM', detail: 'Sent follow-up email with demo deck.' }
    ]
  },
  { 
    id: 'l3', 
    name: 'Stark Industries', 
    phone: '+1122334455', 
    status: 'interested', 
    lastActivity: '2023-10-23', 
    description: 'Follow up on pricing next week',
    activities: [
      { id: 'a5', type: 'call', timestamp: '2023-10-22 11:00 AM', detail: 'Spoke with Pepper. High interest level.' },
      { id: 'a6', type: 'note', timestamp: '2023-10-23 09:00 AM', detail: 'Prepare custom pricing proposal.' }
    ]
  }
];

export const MOCK_REQUESTS: SupportRequest[] = [
  { id: 'r1', userId: '2', userName: 'Sarah Connor', subject: 'Account Activation', status: 'pending', createdAt: '2023-10-26', details: 'Need access to the calling module' },
  { id: 'r2', userId: '3', userName: 'John Doe', subject: 'Billing Issue', status: 'pending', createdAt: '2023-10-26', details: 'Overcharged for seat upgrade' }
];

export const MOCK_NOTIFICATIONS: Notification[] = [
  { id: 'n1', message: 'New lead "Stark Industries" added to pipeline.', type: 'info', timestamp: '10 mins ago', read: false },
  { id: 'n2', message: 'Sarah Connor requested account upgrade.', type: 'warning', timestamp: '1 hour ago', read: false },
  { id: 'n3', message: 'Daily sales report is now available.', type: 'success', timestamp: '3 hours ago', read: true },
  { id: 'n4', message: 'System maintenance scheduled for midnight.', type: 'error', timestamp: '5 hours ago', read: true },
];

export const Icons = {
  Dashboard: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>,
  Users: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>,
  Leads: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>,
  Support: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z"/></svg>,
  Call: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>,
  WhatsApp: () => <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.72.937 3.659 1.432 5.626 1.433h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>,
  Close: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>,
  More: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"/></svg>,
  ChevronDown: () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"/></svg>,
  ChevronUp: () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"/></svg>,
  History: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>,
  Bell: () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>,
};
